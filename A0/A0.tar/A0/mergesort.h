
typedef struct row {
    char rowString[1000];
    char targetCol[500];
} Row;